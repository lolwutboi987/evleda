"""Cross-package safety contracts."""
