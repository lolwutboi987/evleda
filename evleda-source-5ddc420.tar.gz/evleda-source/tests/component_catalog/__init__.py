"""Component catalog tests."""
