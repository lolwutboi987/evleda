"""Design-kernel tests."""

