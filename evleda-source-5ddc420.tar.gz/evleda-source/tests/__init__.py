"""EvlEDA test suite."""
