"""Canonical import mapping tests."""
